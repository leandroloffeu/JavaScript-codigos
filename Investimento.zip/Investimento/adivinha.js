function investimento() {
    let capital = Number(window.prompt("Digite o capitqal inicial: "))
    let taxa = Number(window.prompt("Digite a taxa de juros: "))
    let tempo = Number(window.prompt("Digite o tempo: "))

    let calculo = capital (1+(taxa/100))*tempo

    let res = document.querySelector('section#saida')
    
    res.innerHTML = `O montante é igual a: R$ ${calculo}`
}