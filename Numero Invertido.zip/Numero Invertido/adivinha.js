function reversedNum(){
    let n1 = String(window.prompt('Digite um número: '))
    let res = document.querySelector('section#saida')
    let valor = `${n1.split("").reverse().join("")}`
    let numero = Number(valor)  
    
    res.innerHTML = `<p><h1> o numero invertido: <markj>${(numero)}</markj></h1>`
}