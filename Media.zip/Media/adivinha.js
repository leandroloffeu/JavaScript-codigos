function maior(){
    let n1 = Number(window.prompt('Digite um número: '))
    let n2 = Number(window.prompt('Digite outro Número: '))

    let res = document.querySelector('section#saida')

    res.innerHTML = `<p><h1>O resultado da Média de Dois Múneros é:  <markj>${(n1+n2)/2}</markj></h1>`
}